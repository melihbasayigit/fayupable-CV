var typed = new Typed ('.text',{
    strings:['Backend yazilimcisiyim','Frontend yazilimcisiyim','Mobil yazilimcisiyim','Web tasarimcisiyim'],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
});
